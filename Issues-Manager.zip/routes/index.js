var express = require('express');
var conn = require('../dbconnection/dbconnect');

var router = express.Router();

router.get('/', function(req, res, next) {
    res.render('index');
    fillTechs(req, res);
})

router.post('/savetech', (req, res) => {
    var form = req.body;
    var sqlCmd = 'INSERT INTO techs SET ?';
    conn.query(sqlCmd, form, (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
});

router.get('/listtechs', (req, res) => {
    var sqlCmd = 'SELECT * FROM techs';
    conn.query(sqlCmd, (error, result) => {
        if (error) console.log(error);
        else res.end(JSON.stringify(result));
    })
})

router.get("/listtechs/query", (req, res) => {
    var sqlCmd;
    if (req.query.where === undefined) {
        sqlCmd = `SELECT ${req.query.col} FROM techs;`;
        console.log(sqlCmd);}
    else 
        sqlCmd = `SELECT ${req.query.col} FROM techs WHERE techsid = ${req.query.where};`;
    conn.query(sqlCmd, (err, result) => {
        if (err) {
            console.log(err);
            res.status(404).send("Failed Getting Query");
        }
        else {
            console.log("Responding with technicians query");
            res.status(200).send(result);
        }
    });
});

router.post('/saveissue', (req, res) => {
    var form = req.body;
    console.log(form);
    var sqlCmd = 'INSERT INTO issues SET ?';
    conn.query(sqlCmd, form, (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
});

router.get('/listissues', (req, res) => {
    var sqlCmd = 'SELECT * FROM issues';
    conn.query(sqlCmd, (error, result) => {
        if (error) console.log(error);
        else res.end(JSON.stringify(result));
    })
})

function fillTechs(req, res){
    let col = new URLSearchParams(req.url.split('?')[1]).get('col');
    let where = new URLSearchParams(req.url.split('?')[1]).get('where');
    var sqlCmd;
    if (where === null)
        sqlCmd = `SELECT ${col} FROM techs;`;
    conn.query(sqlCmd, (err, result) => {
        if (err) {
            console.log(err);
            res.end("Failed Getting Query");
        } else {
            console.log("Responding with technician query");
            res.end(JSON.stringify(result));
        }
    });
}

module.exports = router;
