$(document).ready(function () {
    fillSelectTechs();
    listTechs();
    listIssues();
    randomNum();
});

function getRequest(url, callback) {
    let jqxhr = $.ajax({url: url});
    jqxhr.done(data => callback(data));
    jqxhr.fail(err => {
        console.error(err);
        Swal.fire("Error", err.responseText, "error");
    });
}

function fillSelectTechs(){
    $('#technician').html("<option value=''></option>");
    $('#technician').select2({placeholder: "Select a technician"});
    getRequest('/listtechs/query?col=*', data => {
        let options ="";
        for (let i =0; i< data.length; i++){
            let id = `${data[i].techsid}`;
            let fname = `${data[i].techsfname}`;
            options += `<option value="${fname}">${fname}</option>`
        }
        $("#technician").append(options);
    })
}

function saveTech(){
    var formData ={
        techsfname: $('#fname').val(),
        techslname: $('#lname').val(),
        techsemail: $('#email').val(),
        techsphone: $('#phone').val()
    };

    $.ajax({
        url: '/savetech',
        type: 'POST',
        data: formData,
        success: (data, status) => {
            if (status === 'success') {
                alert('Tech Saved successfully!');
                listTechs();
                document.querySelector('#fname').val = "";
            }
        }
    })
}

function listTechs(){
    $.ajax({
        url: '/listtechs',
        type: 'GET',
        success: (data, status) => {
            if (status === 'success'){
                displayData(JSON.parse(data));
            }
        }
    })
};

function displayData(technicians){
    var toPrint = '';

    technicians.forEach(techs => {
        toPrint += `<tr>
                        <td>${techs.techsfname}</td>
                        <td>${techs.techslname}</td>
                        <td>${techs.techsemail}</td>
                        <td>${techs.techsphone}</td>
                        <td style="padding:0">
                            <button class="btn btn-link" onclick="deleteTechnician(${techs.techsid})"><i class="fa fa-trash"></i></button>
                            <button class="btn btn-link" onclick=\'editTechnician(${JSON.stringify(techs)})\'><i class="fa fa-edit"></i></button>
                        </td>
                    </tr>`
    });

    $('#techsData').html(toPrint);

}

function randomNum(){
    let ranNum = Math.floor(Math.random() * 999) + 100;
    $('#randnum').val(ranNum);
}

function saveIssue(){
    //var severity = document.getElementById("severity");
    //var sevtxt = severity.options[severity.selectedIndex].text;
    //var status = document.getElementById("status");
    //var statxt = status.options[status.selectedIndex].text;

    var formData ={
        issuesdesc: $('#desc').val(),
        issuessev: $("[name='severity']").val(),
        issuesstatus: $("[name='status']").val(),
        issuestech: $("[name='technicianid']").val(),
        issuesnum: $('#randnum').val(),
    }

    $.ajax({
        url: '/saveissue',
        type: 'POST',
        data: formData,
        success: function (data, status) {
            if (status === 'success'){
                console.log('Issue Saved Successfully!')
                listIssues();	
            }
        }
    })
}

function listIssues(){
    $.ajax({
        url: '/listissues',
        type: 'GET',
        success: (data, status) => {
            if (status === 'success'){
                displayIssues(JSON.parse(data));
            }
        }
    })
}

function displayIssues(issue){
    toPrint ='';

    issue.forEach(issues =>{
        toPrint += `<tr>
                        <td>${issues.issuesnum}</td>
                        <td>${issues.issuesdesc}</td>
                        <td>${issues.issuessev}</td>
                        <td>${issues.issuesstatus}</td>
                        <td>${issues.issuestech}</td>
                        <td style="padding:0">
                        <button class="btn btn-link" onclick="deleteIssue(${issues.issuesid})"><i class="fa fa-trash"></i></button>
                        <button class="btn btn-link" onclick=\'editIssue(${JSON.stringify(issues)})\'><i class="fa fa-edit"></i></button>
                    </td>
                </tr>`
    });

    $('#issuesData').html(toPrint);
}
